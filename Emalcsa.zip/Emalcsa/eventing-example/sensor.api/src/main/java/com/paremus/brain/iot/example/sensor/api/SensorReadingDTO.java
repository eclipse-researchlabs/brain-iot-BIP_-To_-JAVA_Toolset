/* Copyright 2019 Paremus, Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
package com.paremus.brain.iot.example.sensor.api;

import eu.brain.iot.eventing.api.BrainIoTEvent;

public class SensorReadingDTO extends BrainIoTEvent {

}
