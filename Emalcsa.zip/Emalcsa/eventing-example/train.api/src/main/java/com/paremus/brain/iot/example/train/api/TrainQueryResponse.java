/* Copyright 2019 Paremus, Ltd - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */
package com.paremus.brain.iot.example.train.api;

import eu.brain.iot.eventing.api.BrainIoTEvent;

public class TrainQueryResponse extends BrainIoTEvent {
	
	public String requestor;

}
