package com.paremus.brain.iot.example.main.api;

import eu.brain.iot.eventing.api.BrainIoTEvent;

public class TrainRequest extends BrainIoTEvent {

}
