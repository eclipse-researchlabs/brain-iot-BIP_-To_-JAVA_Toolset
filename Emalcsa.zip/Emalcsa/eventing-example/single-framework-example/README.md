# Single Node Eventing Example

This example runs the light bulb, sensor and smart behaviour on a single node.

## UI

The lightbulb UI is at http://localhost:8080/light-ui/index.html

The sensor UI is at http://localhost:8080/sensor-ui/index.html

