



p0=$1

p1=$2

p2=$3



echo "Source file  $p0 $p1 $p2 "

#! set the location of tensorflow virtual environement
#source /home/baouyaa/my_tensorflow/venv/bin/activate 



#! run the python file
#/home/baouyaa/Brain-IoT/Epsilon/workspace/imreaddatarnn/src/WaterInfraestructure_RNN_PythonTensorflow/nn_make_prediction.py ${p0} ${p1} ${p2}



echo "2.002"
