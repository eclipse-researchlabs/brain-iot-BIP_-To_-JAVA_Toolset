package com.paremus.brain.iot.example.behaviour.impl;

import org.junit.Test;

public class UnitTest {
    
    @Test
    public void testSomething() {
        //TODO add an implementation
    }
    
}
