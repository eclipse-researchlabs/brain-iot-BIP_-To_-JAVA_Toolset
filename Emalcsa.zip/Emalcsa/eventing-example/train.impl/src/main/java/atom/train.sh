



#/home/baouyaa/Brain-IoT/Epsilon/workspace/imreaddatarnn/src/WaterInfraestructure_RNN_PythonTensorflow/nn_train.py

echo "Source file  python training "







