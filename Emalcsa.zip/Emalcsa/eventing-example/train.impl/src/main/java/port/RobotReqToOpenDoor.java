package port;

import type.*;

public class RobotReqToOpenDoor extends Port { 
public RobotReqToOpenDoor(Type<Integer> varid){  
this.varid=varid; 

}
public Type<Integer> varid= new Type<Integer> (); 
}
