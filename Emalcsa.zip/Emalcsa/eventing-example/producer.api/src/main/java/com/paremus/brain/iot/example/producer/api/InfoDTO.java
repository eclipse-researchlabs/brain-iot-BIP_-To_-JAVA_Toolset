package com.paremus.brain.iot.example.producer.api;

import eu.brain.iot.eventing.api.BrainIoTEvent;

public class InfoDTO extends BrainIoTEvent {

	
	public int mess;
}
