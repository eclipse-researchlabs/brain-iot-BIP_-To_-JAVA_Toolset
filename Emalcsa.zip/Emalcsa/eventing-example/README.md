# Eventing Example

This example includes a virtual lightbulb, a virtual sensor, and a smart behaviour which switches on, then slowly dims the light in response to a sensor event