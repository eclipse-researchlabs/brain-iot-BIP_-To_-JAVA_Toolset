@RequireConfigurator
package config;

import org.osgi.service.configurator.annotations.RequireConfigurator;