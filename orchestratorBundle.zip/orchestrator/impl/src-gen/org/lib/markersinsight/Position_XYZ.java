package org.lib.markersinsight;

public class Position_XYZ {

	
	double y = -0.11792459036294335;
	double x = -1.099986603912028;
	double z = 2.7405836974247646 ;
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}
	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getZ() {
		return z;
	}
	public void setZ(double z) {
		this.z = z;
	}
	
	
	
	
}
