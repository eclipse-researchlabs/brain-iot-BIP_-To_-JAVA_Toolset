package org.lib.reply.uncharge;

public class Result {

	
	String message ="Cannot add procedure because goal frame is empty";
	String result ="error";
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	
	
}
