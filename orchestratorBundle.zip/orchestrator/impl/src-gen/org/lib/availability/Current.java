package org.lib.availability;

public class Current {

	String state = "";
	double id = 0;
	String description = "";
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public double getId() {
		return id;
	}
	public void setId(double id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
}
