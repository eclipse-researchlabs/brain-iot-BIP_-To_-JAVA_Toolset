package org.lib.availability;

public class Navigation_status{
	 
	 String state ="";
		
	 String type ="PickComponent";

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	 
	 
}