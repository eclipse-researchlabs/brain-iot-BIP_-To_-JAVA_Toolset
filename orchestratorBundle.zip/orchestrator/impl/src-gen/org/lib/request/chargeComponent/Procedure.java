package org.lib.request.chargeComponent;

public class Procedure {

	
	String pick_frame_id ="docking_station_frame";

	public String getPick_frame_id() {
		return pick_frame_id;
	}

	public void setPick_frame_id(String pick_frame_id) {
		this.pick_frame_id = pick_frame_id;
	}
	
	
}
