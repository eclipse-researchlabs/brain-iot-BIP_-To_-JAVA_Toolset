package org.lib.request.Door;

public class Door {

	double data;

	public double getData() {
		return data;
	}

	public void setData(double data) {
		this.data = data;
	}

	public Door(double data) {
		super();
		this.data = data;
	}

	public Door() {
		super();
	}
	
	
	
}
