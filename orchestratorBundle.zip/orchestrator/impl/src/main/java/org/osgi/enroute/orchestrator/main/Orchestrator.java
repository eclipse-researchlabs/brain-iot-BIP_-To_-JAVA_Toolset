package org.osgi.enroute.orchestrator.main;

import org.osgi.service.component.annotations.Component;

import compound.sim07;

@Component
public class Orchestrator {
    
    public Orchestrator(){
    	new sim07();
    }
    
}
