package atom;

import task.*;


import org.printer.Printer;
import org.printer.Map;


import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;



@Retention(RetentionPolicy.RUNTIME)
public @interface AtomMethodName {
	
	String name();
}
