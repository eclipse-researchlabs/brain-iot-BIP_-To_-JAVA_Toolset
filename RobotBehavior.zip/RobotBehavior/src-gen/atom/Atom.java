package atom;

import task.*;


import org.printer.Printer;
import org.printer.Map;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Observable;
import java.util.Observer;




public class Atom extends Thread  implements Runnable{



	public Atom(){
		
	}
	int step=0;
	int i=0;
	int j=0;
	int time = 0 ;
public void run() {

	Class aClass = getClass();
	synchronized(aClass) {
	Method[] method = aClass.getDeclaredMethods();
	Annotation[] Elementannotations = aClass.getAnnotations();

	for(Annotation annotation : Elementannotations){
	    if(annotation instanceof Task){
	    	Task task = (Task) annotation;
	        time= task.time();
	    }
	}
   // System.out.println("Atom j: " +j+"|");
	while(true){
		
		try {
		//	 System.out.println("Atom j: " +j+"atom i : "+ i);
			
	        if(j<2*(method.length)){

	    		Annotation[] annotations = method[i].getDeclaredAnnotations();	

			for(Annotation annotation : annotations){		
			    if(annotation instanceof AtomMethodName){
			    	AtomMethodName myAnnotation = (AtomMethodName) annotation;


			        Method privateStringMethod;
					try {
						privateStringMethod = this.getClass().getDeclaredMethod(myAnnotation.name(), null);

				        int rs = (Integer) privateStringMethod.invoke(this, null);
				        
				        if(rs==1){
				        	step =step +1;
					    	if(myAnnotation.name().compareTo("initial")==0){
					    	//	System.err.println("\n ["+step+"] Atom name :["+ aClass.getName()+"] Start BIP Behavior on : " + myAnnotation.name()+"\n");
					    					    		
					    	}else{
					    		if(myAnnotation.name().contains("internal")){
							 //       System.err.println("\n ["+step+"]  Atom name :["+ aClass.getName()+"] BIP Internal Bahavior :" + myAnnotation.name()+"\n");	
					    		} else{
					    		//	System.err.println("\n ["+step+"]  Atom name :["+ aClass.getName()+"] BIP port name: " + myAnnotation.name()+"\n");	
						    	}
					    	}
				        }
					} catch (NoSuchMethodException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SecurityException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IllegalArgumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			        

			        
			    }
			
			
			}
			j++;
	        i=j/2;
	        
	        }
	        else{ j=0; i=0; }


			
			sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	}
	
}
boolean portstate;

boolean isEnablePorts(){
	return portstate;
}

void disablePorts(){
	portstate=false;
}

void enablePorts(){
	portstate=true;
}

}

