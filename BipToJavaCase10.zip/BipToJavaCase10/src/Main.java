import java.util.concurrent.Semaphore;

import compound.sim07;


public class Main {

	public static void main(String[] args) {
		new sim07();

	}

}
