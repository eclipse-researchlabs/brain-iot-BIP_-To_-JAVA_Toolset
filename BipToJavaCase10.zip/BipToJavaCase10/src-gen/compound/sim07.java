package compound;


import org.printer.Printer;
import org.printer.Map;
import atom.*;
import port.*;
import type.*;

import task.*;

import connector.*;

// Compound Definition;

@Task(time=5)
public class sim07 extends Compound { 

public sim07( ){ 	
 start();
 } 
@CompoundMethodName(name="init")
public void init( ){
robot= new Robot(new Type<Integer>(1)) ; 

door= new RemoteDoor(new Type<Integer>(2)) ; 

orch= new Orchestrator(new Type<Integer>(3)) ; 

c1 = new robotToOrch (orch.getrob(), robot.getrob() );

c2 = new orchToDoor (orch.getreq(), door.getreq() );

c3 = new robotPosition (orch.getready(), robot.getready() );

c4 = new moveToDock (orch.getreqMoveToDock(), robot.getreqMoveToDock() );

c5 = new moveToUnload (orch.getreqMoveToUnload(), robot.getreqMoveToUnload() );

c6 = new moveToStorage (orch.getreqMoveToStorage(), robot.getreqMoveToStorage() );

}
  public Robot robot; 
 public RemoteDoor door; 
 public Orchestrator orch; 
 public robotToOrch c1; 
 public orchToDoor c2; 
 public robotPosition c3; 
 public moveToDock c4; 
 public moveToUnload c5; 
 public moveToStorage c6; 

}