package atom;


import org.printer.Printer;
import org.printer.Map;
import port.*;

import type.*;

import task.*;

// atom definition;

@Task(time=1)
public class Robot extends Atom { 
// data definition;

Type<Integer> locationX= new Type<Integer> (); 
Type<Integer> locationY= new Type<Integer> (); 
Type<String> txt= new Type<String> (); 
Type<Integer> varid= new Type<Integer> (); 
public Robot( Type<Integer> id){this.id=id; 
start();
 }

Type<Integer> id= new Type<Integer> (); 




Type<Boolean> initial =new Type<Boolean> (true);
Type<Boolean>STARTR=new Type<Boolean> (false);
Type<Boolean>Ready=new Type<Boolean> (false);
Type<Boolean>OnDock=new Type<Boolean> (false);
Type<Boolean>OnUnload=new Type<Boolean> (false);
Type<Boolean>OnStorage=new Type<Boolean> (false);
Position ready;
@PortName(name="ready") 
 public Position getready ( ) {  
 if (ready==null){ready= new Position(varid, locationX, locationY ) ;} 
 
 return ready;}
 
RobotReqToOpenDoor rob;
@PortName(name="rob") 
 public RobotReqToOpenDoor getrob ( ) {  
 if (rob==null){rob= new RobotReqToOpenDoor(varid ) ;} 
 
 return rob;}
 
ReqMoveToDock reqMoveToDock;
@PortName(name="reqMoveToDock") 
 public ReqMoveToDock getreqMoveToDock ( ) {  
 if (reqMoveToDock==null){reqMoveToDock= new ReqMoveToDock(varid, locationX, locationY ) ;} 
 
 return reqMoveToDock;}
 
ReqMoveToUnload reqMoveToUnload;
@PortName(name="reqMoveToUnload") 
 public ReqMoveToUnload getreqMoveToUnload ( ) {  
 if (reqMoveToUnload==null){reqMoveToUnload= new ReqMoveToUnload(varid, locationX, locationY ) ;} 
 
 return reqMoveToUnload;}
 
ReqMoveToStorage reqMoveToStorage;
@PortName(name="reqMoveToStorage") 
 public ReqMoveToStorage getreqMoveToStorage ( ) {  
 if (reqMoveToStorage==null){reqMoveToStorage= new ReqMoveToStorage(varid, locationX, locationY ) ;} 
 
 return reqMoveToStorage;}
 
public ePort silentDockStart= new ePort ( ); 
public ePort silentStorageStart= new ePort ( ); 

 @AtomMethodName(name="initial")
 public int initial(){
 int _r=0;
 if( initial.getVal() ==true  ){locationX.setVal( Map.getDockingX( ) );
locationY.setVal( Map.getDockingY( ) );
varid.setVal(id.getVal() );
_r=1;
 // Activate next states 
STARTR.setVal(true);
initial.setVal(false);
 
   } return _r;}
 @AtomMethodName(name="ready")  
 public int ready(){
 int _r=0;
 if(  STARTR.getVal( )==true  && ready.isAvailable() == false  )
{
ready.setAvailable(true);  
}
if(ready!=null){  
 if(  STARTR.getVal( )==true   && ready.isNotified()  ){
ready.setAvailable(false);

 // Deactivate previous states 
STARTR.setVal(false);
 // Activate next states 
Ready.setVal(true);
 
_r=1;
  ready.conceal(); 
  }


 
} return _r; 
}


 @AtomMethodName(name="reqMoveToUnload")  
 public int reqMoveToUnload(){
 int _r=0;
 if(  Ready.getVal( )==true  && reqMoveToUnload.isAvailable() == false  )
{
reqMoveToUnload.setAvailable(true);  
}
if(reqMoveToUnload!=null){  
 if(  Ready.getVal( )==true   && reqMoveToUnload.isNotified()  ){
reqMoveToUnload.setAvailable(false);

 // Deactivate previous states 
Ready.setVal(false);
 // Activate next states 
OnUnload.setVal(true);
 
_r=1;
  reqMoveToUnload.conceal(); 
  }


 
} return _r; 
}


 @AtomMethodName(name="rob")  
 public int rob(){
 int _r=0;
 if(  OnUnload.getVal( )==true  && rob.isAvailable() == false  )
{
rob.setAvailable(true);  
}
if(rob!=null){  
 if(  OnUnload.getVal( )==true   && rob.isNotified()  ){
rob.setAvailable(false);

 // Deactivate previous states 
OnUnload.setVal(false);
 // Activate next states 
STARTR.setVal(true);
 
_r=1;
  rob.conceal(); 
  }


 
} return _r; 
}


 @AtomMethodName(name="reqMoveToDock")  
 public int reqMoveToDock(){
 int _r=0;
 if(  Ready.getVal( )==true  && reqMoveToDock.isAvailable() == false  )
{
reqMoveToDock.setAvailable(true);  
}
if(reqMoveToDock!=null){  
 if(  Ready.getVal( )==true   && reqMoveToDock.isNotified()  ){
reqMoveToDock.setAvailable(false);

 // Deactivate previous states 
Ready.setVal(false);
 // Activate next states 
OnDock.setVal(true);
 
_r=1;
  reqMoveToDock.conceal(); 
  }


 
} return _r; 
}


 @AtomMethodName(name="silentDockStart")  
 public int silentDockStart(){
 int _r=0;
 if(  OnDock.getVal( )==true  && silentDockStart.isAvailable() == false  )
{
silentDockStart.setAvailable(true);  
}
 if( silentDockStart.isAvailable() ){
silentDockStart.setAvailable(false);

 // Deactivate previous states 
OnDock.setVal(false);
 // Activate next states 
STARTR.setVal(true);
 
_r=1;
  silentDockStart.conceal(); 
  }

 
 return _r;}


 @AtomMethodName(name="reqMoveToStorage")  
 public int reqMoveToStorage(){
 int _r=0;
 if(  Ready.getVal( )==true  && reqMoveToStorage.isAvailable() == false  )
{
reqMoveToStorage.setAvailable(true);  
}
if(reqMoveToStorage!=null){  
 if(  Ready.getVal( )==true   && reqMoveToStorage.isNotified()  ){
reqMoveToStorage.setAvailable(false);

 // Deactivate previous states 
Ready.setVal(false);
 // Activate next states 
OnStorage.setVal(true);
 
_r=1;
  reqMoveToStorage.conceal(); 
  }


 
} return _r; 
}


 @AtomMethodName(name="silentStorageStart")  
 public int silentStorageStart(){
 int _r=0;
 if(  OnStorage.getVal( )==true  && silentStorageStart.isAvailable() == false  )
{
silentStorageStart.setAvailable(true);  
}
 if( silentStorageStart.isAvailable() ){
silentStorageStart.setAvailable(false);

 // Deactivate previous states 
OnStorage.setVal(false);
 // Activate next states 
STARTR.setVal(true);
 
_r=1;
  silentStorageStart.conceal(); 
  }

 
 return _r;}

}